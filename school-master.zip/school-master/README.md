# school
tento soubor je úkol do školy, později sem budu přidávat další úkoly
